//
//  ShareViewController.swift
//  ShareExtensionFile
//
//  Created by Patrick on 07/02/20.
//  Copyright © 2020 Patrick. All rights reserved.
//

import UIKit
import Social
import MobileCoreServices

//class ShareViewController: SLComposeServiceViewController {
class ShareViewController: UIViewController {
    
    
    @IBOutlet weak var imgThumbleImage: UIImageView!
    @IBOutlet weak var txtCaption: UITextView!
    
    
    
    
    
    var url: String?
    var dataType = ""
    
//    override func isContentValid() -> Bool {
//        // Do validation of contentText and/or NSExtensionContext attachments here
//        return true
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))

        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        //tap.cancelsTouchesInView = false

        view.addGestureRecognizer(tap)
        
        getURL()
        
    }

    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    private func getURL() {
        if let item = extensionContext?.inputItems.first as? NSExtensionItem {
            if let itemProvider = item.attachments?.first {
                if itemProvider.hasItemConformingToTypeIdentifier("public.url") {
                    itemProvider.loadItem(forTypeIdentifier: "public.url", options: nil) { (result, error) in
                        print("URL : \(result!)")
                        
                        
                        let string = "\(result!)"
                        if string.contains("watch") {
                            print("exists")
                            var id = ""
                            let videoID = string.components(separatedBy: "/")
                            if videoID.last!.contains("feature=share"){
                                let removeFirst = videoID.last?.dropFirst(6)
                                let removeLast = removeFirst!.dropLast(14)
                                id = "\(removeLast)"
                            }
                            else{
                                let removeFirst = videoID.last?.dropFirst(6)
                                id = "\(removeFirst!)"
                            }
                            self.getImage(path: "https://img.youtube.com/vi/\(id)/sddefault.jpg")
                            self.url = "\(result!)"
                        }
                        else{
                            
                            let videoID = string.components(separatedBy: "/")
                            let id = videoID.last
                            self.getImage(path: "https://img.youtube.com/vi/\(id!)/sddefault.jpg")
                            self.url = "https://www.youtube.com/watch?\(id!)&feature=share"
                        }
                        
                        
                    }
                }
                else if itemProvider.hasItemConformingToTypeIdentifier("public.plain-text") {
                    itemProvider.loadItem(forTypeIdentifier: "public.plain-text", options: nil) { (result, error) in
                        print("Plain text : \(result!)")
                        
                        let string = "\(result!)"
                        if string.contains("watch") {
                            print("exists")
                            var id = ""
                            let videoID = string.components(separatedBy: "/")
                            if videoID.last!.contains("feature=share"){
                                let removeFirst = videoID.last?.dropFirst(6)
                                let removeLast = removeFirst!.dropLast(14)
                                id = "\(removeLast)"
                            }
                            else{
                                let removeFirst = videoID.last?.dropFirst(6)
                                id = "\(removeFirst!)"
                            }
                            self.getImage(path: "https://img.youtube.com/vi/\(id)/sddefault.jpg")
                            self.url = "\(result!)"
                        }
                        else{
                            
                            let videoID = string.components(separatedBy: "/")
                            let id = videoID.last
                            self.getImage(path: "https://img.youtube.com/vi/\(id!)/sddefault.jpg")
                            self.url = "https://www.youtube.com/watch?\(id!)&feature=share"
                        }
                        
                        
                    }
                }
            }
        }
    }
    
    //https://www.youtube.com/watch?v=AsGxpU5bf6g&feature=share
    
    @IBAction func btnShare(_ sender: UIButton) {
        var caption : String!
        if self.txtCaption.text == nil || self.txtCaption.text == "" {
            caption = ""
        }
        else{
            caption = self.txtCaption.text
        }
        
        //        let Url = String(format: "http://dev.wethedevelopers.com/matthewyoung/sitecard/final/API/get_service.php?")
        //        guard let serviceUrl = URL(string: Url) else { return }
        //        let parameterDictionary = ["service_type" : "sc_posts", "sc_post_desc" : self.txtCaption.text!, "sc_post_link" : self.url!]
        //        var request = URLRequest(url: serviceUrl)
        //        request.httpMethod = "POST"
        //        request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
        //        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameterDictionary, options: []) else {
        //            return
        //        }
        //        request.httpBody = httpBody
        //
        //        let session = URLSession.shared
        //        session.dataTask(with: request) { (data, response, error) in
        //            if let response = response {
        //                print(response)
        //            }
        //            if let data = data {
        //                do {
        //                    let json = try JSONSerialization.jsonObject(with: data, options: [])
        //                    print(json)
        //                } catch {
        //                    print(error)
        //                }
        //            }
        //            }.resume()
        
        let request = NSMutableURLRequest(url: NSURL(string: "http://dev.wethedevelopers.com/matthewyoung/sitecard/final/API/get_service.php?")! as URL)
        request.httpMethod = "POST"
        let postString = "service_type=sc_posts&sc_post_desc=\(caption)&sc_post_link=\(self.url!)"
        print(postString)
        request.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, response, error in
            guard error == nil && data != nil else {                                                          // check for fundamental networking error
                print("error=\(error)")
                return
            }
            do {
                if let responseJSON = try JSONSerialization.jsonObject(with: data!) as? [String:AnyObject]{
                    print(responseJSON)
                    print(responseJSON["status"]!)
                    self.extensionContext!.completeRequest(returningItems: nil, completionHandler: nil)
                }
            }
            catch {
                print("Error -> \(error)")
                self.extensionContext!.completeRequest(returningItems: nil, completionHandler: nil)
            }
        }
        task.resume()
    }
    
    
    
    @IBAction func btnCancel(_ sender: UIButton) {
        self.extensionContext!.completeRequest(returningItems: nil, completionHandler: nil)
    }
    
    func getImage(path:String){
        let url = URL(string: path)
            //"http://www.apple.com/euro/ios/ios8/a/generic/images/og.png")

        let task = URLSession.shared.dataTask(with: url!) { data, response, error in
            guard let data = data, error == nil else { return }

            DispatchQueue.main.async() {    // execute on main thread
                self.imgThumbleImage.image = UIImage(data: data)
            }
        }

        task.resume()
    }
}
